#include <opencv2/objdetect.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/dnn.hpp>
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace cv;
using namespace cv::dnn;
using namespace std;

class Detector
{
    enum Mode { Default, Daimler } m;
    HOGDescriptor hog, hog_d;
public:
    Detector() : m(Default), hog(), hog_d()
    {
        hog.setSVMDetector(HOGDescriptor::getDefaultPeopleDetector());
        hog_d = HOGDescriptor(Size(48, 96), Size(16, 16), Size(8, 8), Size(8, 8), 9);
        hog_d.setSVMDetector(HOGDescriptor::getDaimlerPeopleDetector());
    }
    void toggleMode() { m = (m == Default ? Daimler : Default); }
    string modeName() const { return (m == Default ? "Default" : "Daimler"); }
    vector<Rect> detect(Mat img)
    {
        vector<Rect> found;
        if (m == Default)
            hog.detectMultiScale(img, found, 0, Size(8,8), Size(32,32), 1.05, 2, false);
        else if (m == Daimler)
            hog_d.detectMultiScale(img, found, 0.5, Size(8,8), Size(32,32), 1.05, 2, true);
        return found;
    }
    void adjustRect(Rect & r) const
    {
        r.x += cvRound(r.width*0.1);
        r.width = cvRound(r.width*0.8);
        r.y += cvRound(r.height*0.07);
        r.height = cvRound(r.height*0.8);
    }
};

void detectAndDraw(Mat& img, Detector& detector)
{
    vector<Rect> found = detector.detect(img);
    for (vector<Rect>::iterator i = found.begin(); i != found.end(); ++i)
    {
        detector.adjustRect(*i);
        rectangle(img, *i, Scalar(0, 255, 0), 3);
    }
}

int main()
{
    // Create a HOG detector
    Detector hog;
    hog.toggleMode();

    // Open the default camera
    VideoCapture cap(0);
    if (!cap.isOpened()) {
        cout << "Failed to open camera." << endl;
        return -1;
    }

    while (true) {
        // Read a frame from the camera
        Mat frame;
        cap.read(frame);

        // Detect and draw the objects in the frame
        detectAndDraw(frame, hog);

        // Display the output frame
        imshow("Output", frame);

        // Exit if the user presses the 'q' key
        if (waitKey(1) == 'q') {
            break;
        }
    }

    return 0;
}






// this section of code is for video input

/*
int main()
{
    // Open the video file
    cv::VideoCapture cap("video.mp4");
    if (!cap.isOpened())
    {
        std::cerr << "Error: could not open video file" << std::endl;
        return 1;
    }

    // Create a HOG detector
    Detector hog;
    hog.toggleMode();

    // Process each frame in the video
    cv::Mat frame;
    while (cap.read(frame))
    {
        // Detect and draw the objects in the frame
        detectAndDraw(frame, hog);

        // Display the output frame
        cv::imshow("Output", frame);

        // Write the output to a file
        std::ofstream outputFile("output.txt");
        if (outputFile.is_open())
        {
            // Write the number of detected objects to the file
            std::vector<cv::Rect> found = hog.detect(frame);
            outputFile << "Number of objects detected: " << found.size() << std::endl;

            // Write the mode and bounding box coordinates of each detection to the file
            outputFile << "Mode: " << hog.modeName() << std::endl;
            for (std::vector<cv::Rect>::iterator i = found.begin(); i != found.end(); ++i)
            {
                hog.adjustRect(*i);
                outputFile << "x: " << i->x << " y: " << i->y << " w: " << i->width << " h: " << i->height << std::endl;
            }

            outputFile.close();
        }
        else
        {
            std::cerr << "Error: could not open file for writing" << std::endl;
        }

        // Wait for a key press and check if the user wants to exit
        int key = cv::waitKey(1);
        if (key == 27) // ESC key
        {
            break;
        }
    }

    return 0;
}







int main()
{
    Mat img = imread("img.jpeg");
    Detector hog;
    hog.toggleMode();

    detectAndDraw(img, hog);

    imshow("Output", img);
    waitKey();

// Write the output to a file
ofstream outputFile("output.txt");
if (outputFile.is_open())
{
    // Write the number of detected objects to the file
    vector<Rect> found = hog.detect(img);
    outputFile << "Number of objects detected: " << found.size() << endl;

    // Write the mode and bounding box coordinates of each detection to the file
    outputFile << "Mode: " << hog.modeName() << endl;
    for (vector<Rect>::iterator i = found.begin(); i != found.end(); ++i)
    {
        hog.adjustRect(*i);
        outputFile << "x: " << i->x << " y: " << i->y << " w: " << i->width << " h: " << i->height << endl;
    }

    outputFile.close();
}
else
{
    cerr << "Error: could not open file for writing" << endl;
}

return 0;

}*/
