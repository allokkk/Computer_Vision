#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"

#include <iostream>

using namespace cv;
using namespace std;


void help()
{
cout << "\nThis program demonstrates a skeletal transform.\n"
"Usage:\n"
"./skeletal <image_name>, Default is pic1.jpg\n" << endl;
}

int main()
{
int seconds = 3000;
Mat gray, binary, mfblur;
Mat src,dst, cdst, cdstP, wrt_frame;
VideoCapture cam(0);
cam.read(src);
cout<<src.cols<<" "<<src.rows<<" ff\n";
VideoWriter video("result.MPEG",VideoWriter::fourcc('M','P','E','G'),20, Size(src.cols,src.rows));
// Declare the output variables

while(seconds--)
{
cout << "seconds" << seconds;
cam.read(src);

cvtColor(src, gray, COLOR_BGR2GRAY);

threshold(gray, binary, 150, 255, THRESH_BINARY);
binary = 255 - binary;

medianBlur(binary, mfblur, 1);

Mat skel(mfblur.size(), CV_8UC1, Scalar(0));
Mat temp;
Mat eroded;
Mat element = getStructuringElement(MORPH_CROSS, Size(3, 3));
bool done;
int iterations=0;

do
{
erode(mfblur, eroded, element);
dilate(eroded, temp, element);
subtract(mfblur, temp, temp);
bitwise_or(skel, temp, skel);
eroded.copyTo(mfblur);

done = (countNonZero(mfblur) == 0);
iterations++;
} while (!done && (iterations < 100));

cout << "iterations=" << iterations << endl;
cvtColor(skel, wrt_frame, COLOR_GRAY2BGR);

video.write(wrt_frame);
// Show results
namedWindow("Source", 0);
resizeWindow("Source", 500,500);
imshow("Source", src);

namedWindow("graymap", 0);
resizeWindow("graymap", 500,500);
imshow("graymap", gray);

namedWindow("binary", 0);
resizeWindow("binary", 500,500);
imshow("binary", binary);

namedWindow("skeleton", 0);
resizeWindow("skeleton", 500,500);
imshow("skeleton", skel);

// Wait and Exit
char key = waitKey(1);
if(key == 'q')
break;
}
}
